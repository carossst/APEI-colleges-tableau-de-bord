# Val d'Oise - Mini dashboard (GitHub Pages)

## Fichiers
- `index.html` : UI (React + Recharts via CDN)
- `data/valdoise.json` : données (à modifier facilement)

## Modifier les données (le plus simple)
1. Ouvre `data/valdoise.json` sur GitHub
2. Clique sur ✏️ Edit
3. Modifie, puis Commit

## Important (cache GitHub Pages)
Le navigateur peut garder l’ancienne version du JSON. Le code fait déjà un cache-busting (`?v=Date.now()`).
Si tu vois encore une ancienne donnée : hard refresh (Cmd+Shift+R).

## Tester en local
GitHub Pages + fetch nécessite un serveur local.

Dans le dossier du repo :
```bash
python -m http.server 8000
```

Puis ouvrir :
- http://localhost:8000

## Ajouter des scores par collège
Le JSON contient `college_scores` (vide par défaut).
Tu peux y ajouter des entrées de ce type :

```json
{
  "college_id": "ariane",
  "year": 2023,
  "scores": {"espaces": 3, "enseignements": 1, "outils": 3, "eleves": 3, "partenaires": 2},
  "source_note": "à renseigner (page/slide) quand confirmé"
}
```

Conseil strict : ne mets une valeur que si tu as la source (slide/page) sous la main.
